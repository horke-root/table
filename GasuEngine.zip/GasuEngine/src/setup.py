import table
import os
import shutil

def darwin():
    def sub():
        table.pip.install('PySide2')
        table.pip.install('pyinstaller')
        os.system("./bin/pyinstaller -F -w main.py")
        shutil.copy("dist/main.app", table.gethome() + "/Applications/main.app")
        table.Logger.info("Main copied to Application => " + table.gethome() + "/Desktop/main.exe")
    table.venv(sub)


def linux():
    def sub():
        table.pip.install('PySide2')
        table.pip.install('pyinstaller')
        os.system("./bin/pyinstaller -F -w main.py")
        shutil.copy("dist/main", table.gethome() + "/main")
        table.Logger.info("Main copied to Home => " + table.gethome() + "/main")
    table.venv(sub)

def win():
    def sub():
        table.pip.install('PySide2')
        table.pip.install('pyinstaller')
        os.system("start /bin/pyinstaller -F -w main.py")
        shutil.copy("dist/main.exe", table.gethome() + "/Desktop/main.exe")
        table.Logger.info("Main.exe copied to Desktop => " + table.gethome() + "/Desktop/main.exe")
    table.venv(sub)

table.Logger.info('installing a package GasuEngine')
table.windows(win)
table.darwin(darwin)
table.linux(linux)
