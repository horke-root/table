import importlib
def include(lib):
    try:
        return __import__(str(lib))
    except:
        print('not find a lib')