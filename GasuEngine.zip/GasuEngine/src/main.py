import sys
try: from PySide2.QtWidgets import QApplication, QMainWindow
except: print('Don\'t a find PySide2')
from safeimport import include
try: from gui import Ui_MainWindow
except: print('Dont a load gui')
import engine
import speaking

cli_mode = False

class MainWindow(QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.ui = Ui_MainWindow()
        speaking.ui = self.ui

        self.ui.setupUi(self)


print(__name__)

if __name__ == "__main__" and cli_mode == False:
    app = QApplication(sys.argv)

    window = MainWindow()
    window.setWindowTitle("Gasu Simulation")

    speaking.ui = window.ui

    def test():
        speaking.inputer = window.ui.lineEdit.text()
        '''
        speaking.speak(speaking.inputer)
        speaking.setText(speaking.inputer)'''
        engine.start()




    window.ui.pushButton.clicked.connect(test)
    window.show()



    sys.exit(app.exec_())
if __name__ == "__main__" and cli_mode == True:
    while True:
        speaking.inputer = input('==[gasu]> ')
        if speaking.inputer == 'exit':
            sys.exit()
        else:
            print(engine.start())