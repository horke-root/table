import speaking #importing speaking engine
import random # importing random lib
import os

brain_name = ['Меня зовут гасу', 'Гасу' , 'я, гасу приятно познакомится'] # name list
answers_list = ['Да!', "Я не знаю.", 'Нет!', 'Наверное.'] # answers
know_list = ['Думаю что, да', 'Наверное, нет', 'Даже не знаю что сказать', 'Чесно говоря я без понятия']
why_list = ['Потому что', 'я реально не знаю', ' только ты можешь знать почему это', 'не знаю']
why_yes = ['Потому, что да', 'хочу говорить да то и говорю', 'ну а ты что хотел', 'окей, не да, а, ,ага, теперь будет']
why_no = ['Потому что нет', 'просто нравится мне говорить на все нет, и что', 'окей, теперь, ,не, ,нет, а ,,ноу,']
mat_list = ['fuck', 'bitch', 'блядь', 'сука', 'пизда', 'пидор', 'Fuck', 'Bitch', 'Блядь', 'Сука', 'Пизда', 'Пидор', "Порно", "порно", "Porn", "Porn"]
go_to_the_speak = ['окей, давай поболтаем', 'я не против поговорить', 'я готова, к розговору', 'на какую тему будем разговаривать']
#status_list = ['Покачто норм', 'нормально', 'нормальок', 'отлично']
status_list = ['Просто охуенно!', 'Охуительно', 'Залупа блять!']
welcome_list = ['Привет', 'Вечер в хату, мы тут рады.', 'И тебе привет', 'Здарсте', 'Здрастуйте']
def start(): # main start() module
    dont_mat = True
    for i in mat_list: # checking and find a mat
        if speaking.inputer.find(i) != -1:
            print('find a mat')
            dont_mat = False
        elif speaking.inputer.find(i.upper()) != -1:
            print('find a mat')
            dont_mat = False
        else: pass
    if dont_mat: # main if else logic
        if speaking.inputer.find('.') != -1:
            if speaking.inputer.find('поболтаем') != -1 or speaking.inputer.find('поговорим') != -1:
                lchoice = random.choice(go_to_the_speak)
                speaking.setText(lchoice)
                speaking.speak(lchoice)
            elif speaking.inputer.find('Открой') != -1 or speaking.inputer.find('открой') != -1:
                if speaking.inputer.find('майнкрафт') != -1 or speaking.inputer.find('Майнкрафт') != -1:
                    speaking.speak('Открываю майнкрафт.')
                    speaking.setText('Открываю майнкрафт.')
                    os.system('java -jar ~/Desktop/TL.jar &')
            elif speaking.inputer.find('Привет') != -1 or speaking.inputer.find('привет') != -1:
                lchoice = random.choice(welcome_list)
                speaking.setText(lchoice)
                speaking.speak(lchoice)
        elif speaking.inputer.find('?') != -1:
            if speaking.inputer.find('Как') != -1 or speaking.inputer.find('как') != -1:
                if speaking.inputer.find('зовут') != -1 or speaking.inputer.find('Зовут') != -1:
                    bchoice = random.choice(brain_name)
                    speaking.setText(bchoice)
                    speaking.speak(bchoice)
                elif speaking.inputer.find('дела') != -1 or speaking.inputer.find('Дела') != -1 or speaking.inputer.find('делишки') != -1 or speaking.inputer.find('Делишки') != -1 or speaking.inputer.find('поживаешь') != -1 or speaking.inputer.find('Поживаешь') != -1:
                    bchoice = random.choice(status_list)
                    speaking.setText(bchoice)
                    speaking.speak(bchoice)
                elif speaking.inputer.find('ты') != -1 or speaking.inputer.find('Ты') and speaking.inputer.find(
                        'думаешь') != -1 or speaking.inputer.find('думаешь') != -1:
                    bchoice = random.choice(know_list)
                    speaking.setText(bchoice)
                    speaking.speak(bchoice)

            elif speaking.inputer.find('почему') != -1 or speaking.inputer.find('Почему') != -1:
                if speaking.inputer.find('да') != -1 or speaking.inputer.find('Да') != -1:
                    rchoice = random.choice(why_yes)
                    speaking.setText(rchoice)
                    speaking.speak(rchoice)
                elif speaking.inputer.find('нет') != -1 or speaking.inputer.find('Нет') != -1:
                    rchoice = random.choice(why_no)
                    speaking.setText(rchoice)
                    speaking.speak(rchoice)
                else:
                    rchoice = random.choice(why_list)
                    speaking.setText(rchoice)
                    speaking.speak(rchoice)
            else:
                achoice = random.choice(answers_list)
                speaking.setText(achoice)
                speaking.speak(achoice)
        else:
            speaking.setText('Пиши, пожалуйста с раздельными знаками!')
            speaking.speak('Пиши, пожалуйста с раздельными знаками!')
    else:
        speaking.setText('Не матерись пожалуйста!')
        speaking.speak('Не матерись пожалуйста!')