import os

os.system("pyinstaller -F main.py")