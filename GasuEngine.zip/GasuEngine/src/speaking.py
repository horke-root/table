import platform
import os
import main

ui = None
inputer = "default"

def setText(argument):
    if main.cli_mode == False:
        ui.label.setText(argument)
    else:
        return argument

def speak(arg):
    print(platform.system())
    if platform.system() == "Windows":
        try:
            os.system("PowerShell -Command \"Add-Type –AssemblyName System.Speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak(\'hello\');\"")
        except:
            setText("Unbound powershell cmd")

    elif platform.system() == "Darwin":
        try:
            print("mac Os")
            os.system("say \"" + arg + "\"")
            return
        except:
            setText("Fail command say dont working or not found this working only on MacOs!")
    elif platform.system() == "Solaris" or "Linux" or "Ubuntu":
        try:
            print("Linux")
            os.system("espeak \"" + str(arg) + "\"")
        except:
            setText("Dont working espeak or please install espeak!")



